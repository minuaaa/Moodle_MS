moodle-theme_learnr
==============================

LearnR enhances Boost Union with new features, styling, and design elements.  LearnR is a Boost Union child theme for Moodle 4+.. Made for learners and focused on providing unique features to enhance management and delivery of instruction. The LearnR theme builds on the new layouts and user experiences introduced in Moodle 4 and provides a variety of enhancements to core features and styles. The LearnR child theme is focused on students going from “login to learning” quickly and easily.


Installation
------

You must install Boost Union in order to use LearnR.  Please download Boost Union and install first.  Then you can install LearnR.  In the theme chooser select LearnR.  
If you previously installed LearnR you will want to completely uninstall, then install Boost Union and the new LearnR child theme.


Configuration
------

Most settings and theme configurations will be in done in Boost Union.  We strived to only include settings specific to LearnR functionality in the LearnR admin area.  Checkboxes, dropdowns, and color choosers help make configuration simple and easy.