moodle-theme_learnr
==============================

Changes
-------

### LearnR child theme initial release
* Initial release
* Implemented initial functionality and features
* Converted LearnR from a fork of Boost Union to a child theme of Boost Union